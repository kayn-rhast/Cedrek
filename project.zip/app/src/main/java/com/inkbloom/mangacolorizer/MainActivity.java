package com.inkbloom.mangacolorizer;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.content.Intent;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.provider.MediaStore;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.WindowManager;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
  private static final int FILE_REQUEST=1003;
  private WebView web;
  private android.webkit.ValueCallback<Uri[]> fileCallback;
  private final String secretAlias="inkbloom_multi_provider_key_v2";

  @SuppressLint("SetJavaScriptEnabled")
  @Override public void onCreate(Bundle savedInstanceState){
    super.onCreate(savedInstanceState);
    getWindow().setStatusBarColor(Color.rgb(15,17,21));
    getWindow().setNavigationBarColor(Color.rgb(15,17,21));
    getWindow().getDecorView().setSystemUiVisibility(0);
    web=new WebView(this);
    web.setBackgroundColor(Color.rgb(15,17,21));
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(true);
    web.getSettings().setAllowContentAccess(true);
    web.getSettings().setAllowFileAccessFromFileURLs(false);
    web.getSettings().setAllowUniversalAccessFromFileURLs(false);
    web.getSettings().setMediaPlaybackRequiresUserGesture(true);
    web.addJavascriptInterface(new StudioBridge(),"InkBloomAndroid");
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
        Uri uri=request.getUrl();
        return !("file".equals(uri.getScheme()) && uri.toString().startsWith("file:///android_asset/"));
      }
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView view,android.webkit.ValueCallback<Uri[]> callback,FileChooserParams params){
        if(fileCallback!=null)fileCallback.onReceiveValue(null);
        fileCallback=callback;
        Intent intent=new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,params.getMode()==FileChooserParams.MODE_OPEN_MULTIPLE);
        try { startActivityForResult(Intent.createChooser(intent,"Select manga image"),FILE_REQUEST);return true; }
        catch(Exception e){fileCallback=null;return false;}
      }
    });
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }

  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode==FILE_REQUEST && fileCallback!=null){
      Uri[] uris=null;
      if(resultCode==RESULT_OK&&data!=null){
        if(data.getClipData()!=null){
          int size=Math.min(data.getClipData().getItemCount(),100);
          uris=new Uri[size];
          for(int i=0;i<size;i++)uris[i]=data.getClipData().getItemAt(i).getUri();
        }else if(data.getData()!=null)uris=new Uri[]{data.getData()};
      }
      fileCallback.onReceiveValue(uris);
      fileCallback=null;
    }
  }

  @Override public void onBackPressed(){if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
  @Override public void onConfigurationChanged(Configuration config){super.onConfigurationChanged(config);}
  @Override protected void onDestroy(){if(web!=null){web.removeJavascriptInterface("InkBloomAndroid");web.destroy();}super.onDestroy();}

  private void jsResult(JSONObject result){
    runOnUiThread(()->web.evaluateJavascript("window.inkbloomNativeResult("+result.toString()+")",null));
  }
  private void notifyUser(String message){runOnUiThread(()->Toast.makeText(MainActivity.this,message,Toast.LENGTH_LONG).show());}

  private String encryptKey(String apiKey) throws Exception {
    KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
    if(!store.containsAlias(secretAlias)){
      KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
      generator.init(new KeyGenParameterSpec.Builder(secretAlias,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
              .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
      generator.generateKey();
    }
    SecretKey key=((KeyStore.SecretKeyEntry)store.getEntry(secretAlias,null)).getSecretKey();
    Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key);
    byte[] encrypted=cipher.doFinal(apiKey.getBytes(StandardCharsets.UTF_8));
    String iv=Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP);
    String data=Base64.encodeToString(encrypted,Base64.NO_WRAP);
    return iv+":"+data;
  }
  private static boolean validProvider(String name){
    return "gemini".equals(name)||"huggingface".equals(name)||"openai".equals(name);
  }
  private String readKey(String provider){
    if(!validProvider(provider))return "";
    try {
      SharedPreferences prefs=getSharedPreferences("inkbloom_secure",Context.MODE_PRIVATE);
      String value=prefs.getString("api_key_"+provider,"");
      if(value.isEmpty())return "";
      String[] parts=value.split(":",2);if(parts.length!=2)return "";
      KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
      SecretKey key=((KeyStore.SecretKeyEntry)ks.getEntry(secretAlias,null)).getSecretKey();
      Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
      cipher.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)));
      return new String(cipher.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);
    }catch(Exception ex){return "";}
  }
  private static String stringValue(JSONObject json,String name,String defaultVal){
    String text=json.optString(name,defaultVal);
    return text==null?defaultVal:text;
  }
  private static String promptFrom(JSONObject body){
    String style=stringValue(body,"style","classic");
    String direction;
    switch(style){
      case "watercolor":direction="Soft watercolor washes, delicate paper texture, gentle pastel hues and elegant atmospheric color.";break;
      case "cinematic":direction="Cinematic anime colors, nuanced shadows, rich depth, natural material rendering and restrained dramatic lighting.";break;
      case "vibrant":direction="Saturated, dynamic shonen anime cel shading, punchy but harmonious colors, crisp graphic lighting.";break;
      case "vintage":direction="Warm, nostalgic 1990s hand-painted anime, soft shading and subtly muted traditional colors.";break;
      default:direction="Modern anime cel-shading with clean color blocking, believable skin tones, expressive but restrained highlights.";
    }
    String palette=stringValue(body,"palette","auto");
    String paletteDirection;
    switch(palette){
      case "sakura":paletteDirection="sakura pink, lilac, warm ivory, pastels";break;
      case "sunset":paletteDirection="golden amber, orange, terracotta, sunset";break;
      case "ocean":paletteDirection="navy, teal, icy blue, seafoam";break;
      case "neon":paletteDirection="violet, magenta, cyan, dark night tones";break;
      case "earth":paletteDirection="forest green, ochre, warm brown, cream, natural skin tones";break;
      default:paletteDirection="choose natural and consistent colors appropriate to the characters and scene";
    }
    String notes=stringValue(body,"guidance",""); if(notes.length()>900)notes=notes.substring(0,900);
    int ink=body.optInt("ink",80);
    return "COLORIZATION OF EXISTING BLACK-AND-WHITE MANGA ART, NOT A REDRAW. "
      +"Keep the original composition, character identities, faces, costumes, expressions, anatomy, poses, objects, panel layouts, framing and ink lines as faithful to input as possible. "
      +"Paint natural, consistent colors BEHIND the linework. Preserve black ink lines sharply. Original ink priority "+ink+"/100. "
      +(body.optBoolean("preserveText",true)?"Do not modify any existing speech bubbles, dialogue, captions, Japanese text, onomatopoeia or panel borders; keep white dialogue bubble interiors. ":"Do not add any new writing. ")
      +"ART STYLE: "+direction+" PALETTE: "+paletteDirection+". "
      +(notes.isEmpty()?"":"CUSTOM CHARACTER COLOR NOTES: "+notes+". ")
      +(body.has("reference")&&!body.isNull("reference")?"A second image is a reference for colors and character identity ONLY, not the scene composition. ":"")
      +"Output ONLY the fully colorized original manga panel. No labels, watermarks, new objects or contact sheet.";
  }
  private static String readText(InputStream in) throws Exception{
    try(InputStream input=in;ByteArrayOutputStream output=new ByteArrayOutputStream()){
      byte[] buf=new byte[16*1024];int len;
      while((len=input.read(buf))>=0){output.write(buf,0,len);if(output.size()>50*1024*1024)throw new Exception("Response too large.");}
      return output.toString("UTF-8");
    }
  }
  private static String safeError(String message){
    if(message==null||message.isEmpty())return "Request failed.";
    return message.length()>380?message.substring(0,380):message;
  }
  private static JSONObject postJson(String endpoint,String keyHeader,String key,String json) throws Exception {
    HttpURLConnection conn=null;
    try{
      conn=(HttpURLConnection)new URL(endpoint).openConnection();
      conn.setRequestMethod("POST");conn.setConnectTimeout(25000);conn.setReadTimeout(240000);
      conn.setRequestProperty("Content-Type","application/json");
      conn.setRequestProperty("Accept","application/json");
      conn.setRequestProperty(keyHeader,key);
      conn.setDoOutput(true);
      try(OutputStream out=conn.getOutputStream()){out.write(json.getBytes(StandardCharsets.UTF_8));}
      int status=conn.getResponseCode();
      InputStream stream=status>=200&&status<300?conn.getInputStream():conn.getErrorStream();
      String data=readText(stream);
      JSONObject result=new JSONObject(data);
      if(status<200||status>=300){
        JSONObject err=result.optJSONObject("error");
        String message=err==null?result.optString("message", "HTTP "+status):err.optString("message", "HTTP "+status);
        throw new Exception("HTTP "+status+": "+safeError(message));
      }
      return result;
    }finally{if(conn!=null)conn.disconnect();}
  }
  private static JSONObject getJson(String endpoint,String keyHeader,String key) throws Exception {
    HttpURLConnection conn=null;
    try{
      conn=(HttpURLConnection)new URL(endpoint).openConnection();
      conn.setRequestMethod("GET");conn.setConnectTimeout(25000);conn.setReadTimeout(30000);
      conn.setRequestProperty(keyHeader,key);
      int status=conn.getResponseCode();
      String data=readText(status>=200&&status<300?conn.getInputStream():conn.getErrorStream());
      if(status<200||status>=300)throw new Exception("HTTP "+status+": "+safeError(data));
      return new JSONObject(data);
    }finally{if(conn!=null)conn.disconnect();}
  }
  private static byte[] readLimitedImage(String endpoint) throws Exception {
    URL url=new URL(endpoint);
    if(!"https".equals(url.getProtocol()))throw new Exception("Invalid image download URL.");
    HttpURLConnection conn=null;
    try{
      conn=(HttpURLConnection)url.openConnection();
      conn.setConnectTimeout(25000);conn.setReadTimeout(90000);
      conn.setInstanceFollowRedirects(false);
      int code=conn.getResponseCode();
      if(code>=300&&code<400){
        String location=conn.getHeaderField("Location");
        if(location==null||!location.startsWith("https://"))throw new Exception("Unsafe image redirect.");
        conn.disconnect();return readLimitedImageRedirect(location);
      }
      if(code!=200)throw new Exception("Generated image download failed: HTTP "+code);
      try(InputStream in=conn.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
        byte[] buf=new byte[8192];int n;
        while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>24*1024*1024)throw new Exception("Generated image is too large.");}
        return out.toByteArray();
      }
    }finally{if(conn!=null)conn.disconnect();}
  }
  private static byte[] readLimitedImageRedirect(String url) throws Exception {
    HttpURLConnection conn=(HttpURLConnection)new URL(url).openConnection();
    conn.setConnectTimeout(25000);conn.setReadTimeout(90000);
    try{
      if(conn.getResponseCode()!=200)throw new Exception("Generated image redirect failed.");
      try(InputStream in=conn.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
        byte[] buf=new byte[8192];int n;
        while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>24*1024*1024)throw new Exception("Generated image is too large.");}
        return out.toByteArray();
      }
    }finally{conn.disconnect();}
  }
  private static String encodedBody(String uri){
    int pos=uri.indexOf(",");return pos<0?"":uri.substring(pos+1);
  }
  private static String nativeGemini(JSONObject input,String key,String prompt) throws Exception {
    String model=input.optString("model","gemini-3.1-flash-lite-image");
    if(!model.equals("gemini-3.1-flash-lite-image")&&!model.equals("gemini-nano-banana-2.1")&&!model.equals("gemini-3.1-flash-image"))
      model="gemini-3.1-flash-lite-image";
    JSONArray parts=new JSONArray().put(new JSONObject().put("text",prompt));
    String src=input.getString("image");
    parts.put(new JSONObject().put("inline_data",new JSONObject().put("mime_type","image/png").put("data",encodedBody(src))));
    String ref=input.optString("reference","");
    if(ref.startsWith("data:image/"))parts.put(new JSONObject().put("inline_data",new JSONObject().put("mime_type","image/png").put("data",encodedBody(ref))));
    JSONObject req=new JSONObject();
    req.put("contents",new JSONArray().put(new JSONObject().put("role","user").put("parts",parts)));
    req.put("generationConfig",new JSONObject().put("responseModalities",new JSONArray().put("TEXT").put("IMAGE")));
    JSONObject result=postJson("https://generativelanguage.googleapis.com/v1beta/models/"+model+":generateContent", "x-goog-api-key",key,req.toString());
    JSONArray candidates=result.optJSONArray("candidates");
    if(candidates!=null){
      for(int i=0;i<candidates.length();i++){
        JSONObject content=candidates.getJSONObject(i).optJSONObject("content");
        JSONArray output=content==null?null:content.optJSONArray("parts");
        if(output!=null)for(int j=0;j<output.length();j++){
          JSONObject img=output.getJSONObject(j).optJSONObject("inlineData");
          if(img==null)img=output.getJSONObject(j).optJSONObject("inline_data");
          if(img!=null&&img.optString("data","").length()>10)
            return "data:"+img.optString("mimeType",img.optString("mime_type","image/png"))+";base64,"+img.getString("data");
        }
      }
    }
    throw new Exception("Gemini did not return an image. Check image-model access and billing in Google AI Studio.");
  }
  private static String nativeHuggingFace(JSONObject input,String key,String prompt) throws Exception {
    String route="fal-ai/qwen-image-edit/image-to-image";

    String base="https://router.huggingface.co/fal-ai/"+route;
    String suffix="?_subdomain=queue";
    JSONObject req=new JSONObject().put("prompt",prompt).put("image_url",input.getString("image"))
           .put("image_urls",new JSONArray().put(input.getString("image")));
    // Some models ignore the extra image_urls field. Only the panel is required for the free-credit pathway.
    JSONObject response=postJson(base+suffix,"Authorization","Bearer "+key,req.toString());
    JSONObject result=response;
    String id=response.optString("request_id","");
    if(!id.isEmpty()){
      String responseUrl=response.optString("response_url","");
      String path=new URL(responseUrl).getPath();
      if(!path.matches("/[A-Za-z0-9_\\-./]+")||!path.contains(id))throw new Exception("Unexpected Hugging Face queue response.");
      String queueUrl="https://router.huggingface.co/fal-ai"+path+suffix;
      String state="";
      for(int i=0;i<240;i++){
        Thread.sleep(1500);
        JSONObject progress=getJson(queueUrl.replace("?", "/status?"),"Authorization","Bearer "+key);
        state=progress.optString("status","");
        if("COMPLETED".equals(state))break;
        if("FAILED".equals(state)||"CANCELLED".equals(state))throw new Exception("Hugging Face queue failed: "+safeError(progress.optString("error",state)));
        if(i==239)throw new Exception("Hugging Face queue timed out. Try again later.");
      }
      result=getJson(queueUrl,"Authorization","Bearer "+key);
    }
    JSONArray imgs=result.optJSONArray("images");
    if(imgs==null||imgs.length()==0)throw new Exception("Hugging Face returned no edited image.");
    String image=imgs.getJSONObject(0).optString("url","");
    if(image.startsWith("data:image/"))return image;
    byte[] bytes=readLimitedImage(image);
    return "data:image/png;base64,"+Base64.encodeToString(bytes,Base64.NO_WRAP);
  }
  private static String nativeOpenAI(JSONObject input,String key,String prompt) throws Exception {
    String requested=input.optString("model", "gpt-image-2.6-flare");
    String model=requested.equals("gpt-image-2.6-sunburst")?requested:"gpt-image-2.6-flare";
    JSONArray images=new JSONArray().put(new JSONObject().put("image_url",input.getString("image")));
    String ref=input.optString("reference","");
    if(ref.startsWith("data:image/"))images.put(new JSONObject().put("image_url",ref));
    String quality=input.optString("quality","medium");
    if(!quality.equals("low")&&!quality.equals("medium")&&!quality.equals("high"))quality="medium";
    JSONObject req=new JSONObject().put("model",model).put("images",images)
       .put("prompt",prompt).put("quality",quality).put("size","auto").put("output_format","png").put("n",1);
    JSONObject result=postJson("https://api.openai.com/v1/images/edits","Authorization","Bearer "+key,req.toString());
    JSONArray data=result.optJSONArray("data");
    if(data==null||data.length()==0)throw new Exception("OpenAI returned no image.");
    String b64=data.getJSONObject(0).optString("b64_json","");
    if(b64.isEmpty())throw new Exception("OpenAI returned no PNG data.");
    return "data:image/png;base64,"+b64;
  }
  private void generate(String payload){
    JSONObject outcome=new JSONObject();
    try {
      JSONObject input=new JSONObject(payload);
      String provider=input.optString("provider","gemini");
      if(!validProvider(provider))throw new Exception("Unknown AI provider.");
      String key=readKey(provider);
      if(key.isEmpty())throw new Exception("Add your "+provider+" API key in settings.");
      String original=input.optString("image","");
      if(!original.startsWith("data:image/png;base64,")||original.length()<200||original.length()>19_000_000)
        throw new Exception("Choose a valid manga PNG under 14 MB.");
      String prompt=promptFrom(input);
      String image;
      switch(provider){
        case "gemini":image=nativeGemini(input,key,prompt);break;
        case "huggingface":image=nativeHuggingFace(input,key,prompt);break;
        default:image=nativeOpenAI(input,key,prompt);break;
      }
      outcome.put("image",image);
    }catch(Exception e){
      try{outcome.put("error",safeError(e.getMessage()));}catch(Exception ignored){}
    }
    jsResult(outcome);
  }
  public final class StudioBridge {
    @JavascriptInterface public boolean hasApiKey(String provider){return !readKey(provider).isEmpty();}
    @JavascriptInterface public boolean setApiKey(String provider,String key){
      try {
        if(!validProvider(provider)||key==null||key.trim().length()<15||key.length()>500)
          return false;
        String encrypted=encryptKey(key.trim());
        getSharedPreferences("inkbloom_secure",Context.MODE_PRIVATE).edit().putString("api_key_"+provider,encrypted).apply();
        return true;
      }catch(Exception e){return false;}
    }
    @JavascriptInterface public void clearApiKey(String provider){
      if(validProvider(provider))getSharedPreferences("inkbloom_secure",Context.MODE_PRIVATE).edit().remove("api_key_"+provider).apply();
    }
    @JavascriptInterface public void colorize(String payload){new Thread(()->generate(payload)).start();}
    @JavascriptInterface public void savePngWithId(String dataUri,String fileName,String id){new Thread(()->{
      JSONObject message=new JSONObject();
      try{
        String safeName=fileName==null?"manga-colorized.png":fileName.replaceAll("[^a-zA-Z0-9_.-]","_");
        if(!safeName.endsWith(".png"))safeName+=".png";
        int split=dataUri==null?-1:dataUri.indexOf("base64,");
        if(split<0||!dataUri.startsWith("data:image/"))throw new Exception("Image is not a valid base64 PNG/JPEG/WebP.");
        byte[] source=Base64.decode(dataUri.substring(split+7),Base64.DEFAULT);
        if(source.length>24*1024*1024)throw new Exception("Result exceeds the image size limit.");
        android.graphics.Bitmap bmp=android.graphics.BitmapFactory.decodeByteArray(source,0,source.length);
        if(bmp==null)throw new Exception("Could not decode generated image.");
        byte[] png;
        try(ByteArrayOutputStream buffer=new ByteArrayOutputStream()){
          bmp.compress(android.graphics.Bitmap.CompressFormat.PNG,100,buffer);
          png=buffer.toByteArray();
        }finally{bmp.recycle();}
        ContentValues values=new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME,safeName);
        values.put(MediaStore.Images.Media.MIME_TYPE,"image/png");
        if(Build.VERSION.SDK_INT>=29){
          values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/InkBloom");
          values.put(MediaStore.Images.Media.IS_PENDING,1);
        }
        Uri target=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
        if(target==null)throw new Exception("The Android gallery is not available.");
        try(OutputStream out=getContentResolver().openOutputStream(target)){
          if(out==null)throw new Exception("Could not open gallery output.");
          out.write(png);
        }catch(Exception writeFailure){getContentResolver().delete(target,null,null);throw writeFailure;}
        if(Build.VERSION.SDK_INT>=29){
          ContentValues complete=new ContentValues();complete.put(MediaStore.Images.Media.IS_PENDING,0);
          getContentResolver().update(target,complete,null,null);
        }
        message.put("success",true);
      }catch(Exception e){
        try{message.put("success",false).put("error",safeError(e.getMessage()));}catch(Exception ignored){}
      }
      try{message.put("id",id==null?"":id);}catch(Exception ignored){}
      runOnUiThread(()->web.evaluateJavascript("window.inkbloomSaveResult("+message.toString()+")",null));
    }).start();}
    @JavascriptInterface public void savePng(String dataUri,String fileName){new Thread(()->{
      try{
        if(dataUri==null||!dataUri.startsWith("data:image/png;base64,"))throw new Exception("Invalid PNG data");
        String safeName=fileName==null?"inkbloom.png":fileName.replaceAll("[^a-zA-Z0-9_.-]","_");
        if(!safeName.endsWith(".png"))safeName+=".png";
        byte[] bytes=Base64.decode(dataUri.substring("data:image/png;base64,".length()),Base64.DEFAULT);
        ContentValues values=new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME,safeName);
        values.put(MediaStore.Images.Media.MIME_TYPE,"image/png");
        if(Build.VERSION.SDK_INT>=29){
          values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/InkBloom");
          values.put(MediaStore.Images.Media.IS_PENDING,1);
        }
        Uri output=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
        if(output==null)throw new Exception("Gallery is unavailable.");
        try(OutputStream stream=getContentResolver().openOutputStream(output)){
          if(stream==null)throw new Exception("Cannot write gallery image.");
          stream.write(bytes);
        }
        if(Build.VERSION.SDK_INT>=29){
          ContentValues ready=new ContentValues();ready.put(MediaStore.Images.Media.IS_PENDING,0);
          getContentResolver().update(output,ready,null,null);
        }
        notifyUser("Saved to Pictures / InkBloom");
      }catch(Exception e){notifyUser("Could not save PNG: "+e.getMessage());}
    }).start();}
  }
}
