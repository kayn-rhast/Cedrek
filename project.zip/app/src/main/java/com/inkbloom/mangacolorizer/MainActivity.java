package com.inkbloom.mangacolorizer;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.content.Intent;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.provider.MediaStore;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.WindowManager;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
  private static final int FILE_REQUEST=1003;
  private WebView web;
  private android.webkit.ValueCallback<Uri[]> fileCallback;
  private final String secretAlias="inkbloom_personal_openai_api_key";

  @SuppressLint("SetJavaScriptEnabled")
  @Override public void onCreate(Bundle savedInstanceState){
    super.onCreate(savedInstanceState);
    getWindow().setStatusBarColor(Color.rgb(15,17,21));
    getWindow().setNavigationBarColor(Color.rgb(15,17,21));
    getWindow().getDecorView().setSystemUiVisibility(0);
    web=new WebView(this);
    web.setBackgroundColor(Color.rgb(15,17,21));
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(true);
    web.getSettings().setAllowContentAccess(true);
    web.getSettings().setAllowFileAccessFromFileURLs(false);
    web.getSettings().setAllowUniversalAccessFromFileURLs(false);
    web.getSettings().setMediaPlaybackRequiresUserGesture(true);
    web.addJavascriptInterface(new StudioBridge(),"InkBloomAndroid");
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
        Uri uri=request.getUrl();
        return !("file".equals(uri.getScheme()) && uri.toString().startsWith("file:///android_asset/"));
      }
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView view,android.webkit.ValueCallback<Uri[]> callback,FileChooserParams params){
        if(fileCallback!=null)fileCallback.onReceiveValue(null);
        fileCallback=callback;
        Intent intent=new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);
        try { startActivityForResult(Intent.createChooser(intent,"Select manga image"),FILE_REQUEST);return true; }
        catch(Exception e){fileCallback=null;return false;}
      }
    });
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }

  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode==FILE_REQUEST && fileCallback!=null){
      Uri[] uris=(resultCode==RESULT_OK && data!=null && data.getData()!=null)?new Uri[]{data.getData()}:null;
      fileCallback.onReceiveValue(uris);
      fileCallback=null;
    }
  }

  @Override public void onBackPressed(){if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
  @Override public void onConfigurationChanged(Configuration config){super.onConfigurationChanged(config);}
  @Override protected void onDestroy(){if(web!=null){web.removeJavascriptInterface("InkBloomAndroid");web.destroy();}super.onDestroy();}

  private void jsResult(JSONObject result){
    runOnUiThread(()->web.evaluateJavascript("window.inkbloomNativeResult("+result.toString()+")",null));
  }
  private void notifyUser(String message){runOnUiThread(()->Toast.makeText(MainActivity.this,message,Toast.LENGTH_LONG).show());}

  private String encryptKey(String apiKey) throws Exception {
    KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
    if(!store.containsAlias(secretAlias)){
      KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
      generator.init(new KeyGenParameterSpec.Builder(secretAlias,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
              .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
      generator.generateKey();
    }
    SecretKey key=((KeyStore.SecretKeyEntry)store.getEntry(secretAlias,null)).getSecretKey();
    Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key);
    byte[] encrypted=cipher.doFinal(apiKey.getBytes(StandardCharsets.UTF_8));
    String iv=Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP);
    String data=Base64.encodeToString(encrypted,Base64.NO_WRAP);
    return iv+":"+data;
  }
  private String readKey(){
    try {
      SharedPreferences prefs=getSharedPreferences("inkbloom_secure",Context.MODE_PRIVATE);
      String value=prefs.getString("api_key","");
      if(value.isEmpty())return "";
      String[] parts=value.split(":",2);if(parts.length!=2)return "";
      KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
      SecretKey key=((KeyStore.SecretKeyEntry)ks.getEntry(secretAlias,null)).getSecretKey();
      Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
      cipher.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)));
      return new String(cipher.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);
    }catch(Exception ex){return "";}
  }
  private static String stringValue(JSONObject json,String name,String defaultVal){
    String text=json.optString(name,defaultVal);
    return text==null?defaultVal:text;
  }
  private static String promptFrom(JSONObject body){
    String style=stringValue(body,"style","classic");
    String direction;
    switch(style){
      case "watercolor":direction="Soft watercolor washes, delicate paper texture, gentle pastel hues and elegant atmospheric color.";break;
      case "cinematic":direction="Cinematic anime colors, nuanced shadows, rich depth, natural material rendering and restrained dramatic lighting.";break;
      case "vibrant":direction="Saturated, dynamic shonen anime cel shading, punchy but harmonious colors, crisp graphic lighting.";break;
      case "vintage":direction="Warm, nostalgic 1990s hand-painted anime, soft shading and subtly muted traditional colors.";break;
      default:direction="Modern anime cel-shading with clean color blocking, believable skin tones, expressive but restrained highlights.";
    }
    String palette=stringValue(body,"palette","auto");
    String paletteDirection;
    switch(palette){
      case "sakura":paletteDirection="sakura pink, lilac, warm ivory, pastels";break;
      case "sunset":paletteDirection="golden amber, orange, terracotta, sunset";break;
      case "ocean":paletteDirection="navy, teal, icy blue, seafoam";break;
      case "neon":paletteDirection="violet, magenta, cyan, dark night tones";break;
      case "earth":paletteDirection="forest green, ochre, warm brown, cream, natural skin tones";break;
      default:paletteDirection="choose natural and consistent colors appropriate to the characters and scene";
    }
    String notes=stringValue(body,"guidance",""); if(notes.length()>900)notes=notes.substring(0,900);
    int ink=body.optInt("ink",80);
    return "COLORIZATION OF EXISTING BLACK-AND-WHITE MANGA ART, NOT A REDRAW. "
      +"Keep the original composition, character identities, faces, costumes, expressions, anatomy, poses, objects, panel layouts, framing and ink lines as faithful to input as possible. "
      +"Paint natural, consistent colors BEHIND the linework. Preserve black ink lines sharply. Original ink priority "+ink+"/100. "
      +(body.optBoolean("preserveText",true)?"Do not modify any existing speech bubbles, dialogue, captions, Japanese text, onomatopoeia or panel borders; keep white dialogue bubble interiors. ":"Do not add any new writing. ")
      +"ART STYLE: "+direction+" PALETTE: "+paletteDirection+". "
      +(notes.isEmpty()?"":"CUSTOM CHARACTER COLOR NOTES: "+notes+". ")
      +(body.has("reference")&&!body.isNull("reference")?"A second image is a reference for colors and character identity ONLY, not the scene composition. ":"")
      +"Output ONLY the fully colorized original manga panel. No labels, watermarks, new objects or contact sheet.";
  }
  private static String readText(InputStream in) throws Exception{
    try(InputStream input=in;ByteArrayOutputStream output=new ByteArrayOutputStream()){
      byte[] buf=new byte[16*1024];int len;
      while((len=input.read(buf))>=0){output.write(buf,0,len);if(output.size()>50*1024*1024)throw new Exception("Response too large.");}
      return output.toString("UTF-8");
    }
  }
  private void generate(String payload){
    JSONObject outcome=new JSONObject();HttpURLConnection conn=null;
    try {
      String key=readKey();if(key.isEmpty())throw new Exception("Add your OpenAI API key to enable coloring.");
      JSONObject input=new JSONObject(payload);
      String original=stringValue(input,"image","");
      if(!original.startsWith("data:image/")||original.length()<200)throw new Exception("Choose a valid manga image first.");
      JSONArray images=new JSONArray();images.put(new JSONObject().put("image_url",original));
      String reference=input.optString("reference","");
      if(reference.startsWith("data:image/"))images.put(new JSONObject().put("image_url",reference));
      String model="sunburst".equals(input.optString("model"))?"gpt-image-2.6-sunburst":"gpt-image-2.6-flare";
      String quality=stringValue(input,"quality","medium");
      if(!quality.equals("low")&&!quality.equals("medium")&&!quality.equals("high"))quality="medium";
      JSONObject req=new JSONObject();
      req.put("model",model);req.put("images",images);req.put("prompt",promptFrom(input));
      req.put("quality",quality);req.put("size","auto");req.put("output_format","png");req.put("n",1);
      conn=(HttpURLConnection)new URL("https://api.openai.com/v1/images/edits").openConnection();
      conn.setRequestMethod("POST");conn.setConnectTimeout(20000);conn.setReadTimeout(240000);
      conn.setRequestProperty("Authorization","Bearer "+key);
      conn.setRequestProperty("Content-Type","application/json");
      conn.setRequestProperty("Accept","application/json");
      conn.setDoOutput(true);
      try(OutputStream out=conn.getOutputStream()){out.write(req.toString().getBytes(StandardCharsets.UTF_8));}
      int status=conn.getResponseCode();
      String response=readText(status>=200&&status<300?conn.getInputStream():conn.getErrorStream());
      JSONObject parsed=new JSONObject(response);
      if(status<200||status>=300){
        JSONObject apiError=parsed.optJSONObject("error");
        String message=apiError==null?("HTTP "+status):apiError.optString("message","HTTP "+status);
        throw new Exception(message.length()>320?message.substring(0,320):message);
      }
      JSONArray data=parsed.optJSONArray("data");
      if(data==null||data.length()==0)throw new Exception("AI returned no image. Please try again.");
      String b64=data.getJSONObject(0).optString("b64_json","");
      if(b64.isEmpty())throw new Exception("AI returned no PNG image.");
      outcome.put("image","data:image/png;base64,"+b64);
    }catch(Exception e){
      try{outcome.put("error",e.getMessage()==null?"Request failed. Check your network.":e.getMessage());}catch(Exception ignored){}
    }finally{if(conn!=null)conn.disconnect();}
    jsResult(outcome);
  }
  public final class StudioBridge {
    @JavascriptInterface public boolean hasApiKey(){return !readKey().isEmpty();}
    @JavascriptInterface public void setApiKey(String key){
      try{
        if(key==null||!key.startsWith("sk-")||key.length()>300)throw new Exception("Invalid API key format.");
        String encrypted=encryptKey(key.trim());
        getSharedPreferences("inkbloom_secure",Context.MODE_PRIVATE).edit().putString("api_key",encrypted).apply();
      }catch(Exception e){notifyUser("Unable to securely store API key.");}
    }
    @JavascriptInterface public void colorize(String payload){new Thread(()->generate(payload)).start();}
    @JavascriptInterface public void savePng(String dataUri,String fileName){new Thread(()->{
      try{
        if(dataUri==null||!dataUri.startsWith("data:image/png;base64,"))throw new Exception("Invalid PNG data");
        String safeName=fileName==null?"inkbloom.png":fileName.replaceAll("[^a-zA-Z0-9_.-]","_");
        if(!safeName.endsWith(".png"))safeName+=".png";
        byte[] bytes=Base64.decode(dataUri.substring("data:image/png;base64,".length()),Base64.DEFAULT);
        ContentValues values=new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME,safeName);
        values.put(MediaStore.Images.Media.MIME_TYPE,"image/png");
        if(Build.VERSION.SDK_INT>=29){
          values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/InkBloom");
          values.put(MediaStore.Images.Media.IS_PENDING,1);
        }
        Uri output=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
        if(output==null)throw new Exception("Gallery is unavailable.");
        try(OutputStream stream=getContentResolver().openOutputStream(output)){
          if(stream==null)throw new Exception("Cannot write gallery image.");
          stream.write(bytes);
        }
        if(Build.VERSION.SDK_INT>=29){
          ContentValues ready=new ContentValues();ready.put(MediaStore.Images.Media.IS_PENDING,0);
          getContentResolver().update(output,ready,null,null);
        }
        notifyUser("Saved to Pictures / InkBloom");
      }catch(Exception e){notifyUser("Could not save PNG: "+e.getMessage());}
    }).start();}
  }
}
