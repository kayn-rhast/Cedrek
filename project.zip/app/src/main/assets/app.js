'use strict';
const $ = id => document.getElementById(id);
const state = {
  source:'assets/demo-original.svg',result:'assets/demo-colored.svg',processedResult:null,
  sourceData:null,referenceData:null,filename:'demo_panel.png',sample:true,connected:false,generating:false,
  style:'classic', compare:52, dimensions:{w:760,h:1100},history:[],activeHistory:null,inkVersion:0,
  queue:[],selectedIndex:-1,stopRequested:false,batchFinished:0,batchTotal:0,provider:'huggingface'
};
const models={
  huggingface:[['qwen','Qwen Image Edit · trial credits']],
  gemini:[['gemini-3.1-flash-lite-image','Gemini Flash Lite Image · economy'],['gemini-nano-banana-2.1','Nano Banana 2.1 · best consistency'],['gemini-3.1-flash-image','Gemini Flash Image · detail']],
  openai:[['gpt-image-2.6-flare','GPT Image 2.6 Flare · fast'],['gpt-image-2.6-sunburst','GPT Image 2.6 Sunburst · high detail']]
};
const providerText={
  huggingface:'Hugging Face gives limited monthly starter credits (currently approximately $0.10 on eligible free accounts), subject to change. Image editing uses Qwen. Your token must allow Inference Providers; requests can exhaust credits quickly.',
  gemini:'Gemini image-editing API has no free-tier image generation according to Google pricing. A billing-enabled Google AI Studio project and Gemini API key are required.',
  openai:'OpenAI image editing uses your API account balance. API usage may be charged per image.'
};
let toastTimer, pendingColorization=null, inkDebounce, galleryPending=new Map();
function toast(message,error=false){ const el=$('toast');el.textContent=message;el.classList.toggle('error',error);el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),4900); }
function native(){return window.InkBloomAndroid||null;}
function selectProvider(provider){
  if(!models[provider])provider='huggingface';
  state.provider=provider;$('provider').value=provider;
  $('model').replaceChildren();
  for(const [id,name] of models[provider]){let el=document.createElement('option');el.value=id;el.textContent=name;$('model').append(el);}
  $('providerHelp').textContent=providerText[provider];
  $('providerTier').textContent=provider==='huggingface'?'Tiny starter credits':provider==='gemini'?'Billing required':'Paid API';
  $('apiKey').value='';$('apiKey').placeholder=provider==='huggingface'?'hf_...':provider==='gemini'?'AIza...':'sk-...';
  $('referenceButton').disabled=provider==='huggingface';$('referenceButton').title=provider==='huggingface'?'Reference images available on Gemini and OpenAI':'Add color reference image';
  checkConnection();
}
function checkConnection(){
  state.connected=!!(native() && InkBloomAndroid.hasApiKey(state.provider));
  $('connection').classList.toggle('connected',state.connected);$('connection').classList.toggle('offline',!state.connected);
  $('connectionText').textContent=state.connected?state.provider+' ready':'Add '+state.provider+' key';
  $('keyStatus').textContent=state.connected?'✓ Key saved securely':'No key saved for '+state.provider;
  $('keyStatus').classList.toggle('ready',state.connected);
  $('clearApiKey').disabled=!state.connected;
}
function setCompare(value){let v=Math.max(0,Math.min(100,Number(value)));state.compare=v;$('compareDivider').style.left=v+'%';$('afterImage').style.clipPath=`inset(0 ${100-v}% 0 0)`;$('compareRange').value=v;$('compareValue').textContent=Math.round(v)+'%';}
function updatePreview(){
  $('artViewport').style.aspectRatio=`${state.dimensions.w}/${state.dimensions.h}`;
  $('beforeImage').src=state.source;
  $('afterImage').src=state.processedResult||state.result||state.source;
  $('afterImage').style.display=state.result?'block':'none';
  $('compareDivider').style.display=state.result?'block':'none';
  $('compareRange').disabled=!state.result;$('downloadButton').disabled=!state.result||state.sample;
  $('previewCaption').textContent=state.sample?'ILLUSTRATIVE DEMO':state.result?'COLOR RESULT':'ORIGINAL IMAGE';
  $('resolution').textContent=`${state.dimensions.w} × ${state.dimensions.h} PX`;
  $('fileName').textContent=state.filename;
  $('resultStatus').textContent=state.sample?'Illustrative sample — not AI generated':state.result?'Colorized panel — ready to save':'Original page selected';
  $('resultStatusDot').classList.toggle('muted',!state.result);
}
function promiseNative(payload){return new Promise((resolve,reject)=>{if(!native())return reject(Error('Android service unavailable.'));pendingColorization={resolve,reject};InkBloomAndroid.colorize(JSON.stringify(payload));});}
window.inkbloomNativeResult=function(result){if(!pendingColorization)return;const p=pendingColorization;pendingColorization=null;if(result.error)p.reject(Error(result.error));else p.resolve(result);};
window.inkbloomSaveResult=function(result){const item=galleryPending.get(result.id);if(!item)return;galleryPending.delete(result.id);item.status=result.success?'saved':'save-error';item.error=result.success?'':'Gallery save failed: '+(result.error||'unknown');renderQueue();if(!result.success)toast('Gallery save error: '+item.filename,true);};
function sizeError(file){if(!file)return 'No image selected.';if(!['image/png','image/jpeg','image/webp'].includes(file.type))return 'Only PNG, JPG or WebP supported.';if(file.size>12*1024*1024)return 'File exceeds 12 MB: '+file.name;return '';}
function loadImage(src){return new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(Error('Unable to load manga image.'));img.src=src;});}
async function encodeSrc(src,maxEdge=1800){const img=await loadImage(src);const scale=Math.min(1,maxEdge/Math.max(img.naturalWidth,img.naturalHeight));const w=Math.max(1,Math.round(img.naturalWidth*scale)),h=Math.max(1,Math.round(img.naturalHeight*scale));const c=document.createElement('canvas');c.width=w;c.height=h;let ctx=c.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,w,h);ctx.drawImage(img,0,0,w,h);return {data:c.toDataURL('image/png'),w,h};}
async function encodeFile(file,maxEdge=1800){const url=URL.createObjectURL(file);try{return await encodeSrc(url,maxEdge);}finally{URL.revokeObjectURL(url);}}
function loadSample(){state.source='assets/demo-original.svg';state.sourceData=null;state.result='assets/demo-colored.svg';state.processedResult=null;state.sample=true;state.filename='demo_panel.png';state.dimensions={w:760,h:1100};state.activeHistory=null;setCompare(52);updatePreview();renderHistory();}
async function handleFiles(files){
  if(state.generating)return toast('Stop the current batch before changing the queue.',true);
  const valid=[];
  for(const file of files){const err=sizeError(file);if(err){toast(err,true);continue;}valid.push(file);}
  if(!valid.length)return;
  const slots=100-state.queue.length;
  if(slots<=0)return toast('This queue is full (100 images). Clear it to start a new batch.',true);
  valid.slice(0,slots).forEach(file=>{state.queue.push({id:Date.now()+'_'+Math.random().toString(36).slice(2),file,filename:file.name,status:'waiting',error:'',resultData:null,sourceData:null,dimensions:null});});
  if(valid.length>slots)toast('Only the first 100 images were added.',true);
  if(state.queue.length&&state.selectedIndex===-1)await selectItem(0);
  renderQueue();toast(`${Math.min(valid.length,slots)} manga page(s) added to batch.`);
}
function stageStatus(item){return ({waiting:'Queued',working:'Colorizing…',saved:'Saved ✓',saving:'Saving…',done:'Ready ✓',error:'Failed', 'save-error':'Save failed'})[item.status]||item.status;}
function renderQueue(){
  const q=state.queue,done=q.filter(x=>['saved','done','saving','save-error'].includes(x.status)).length,failed=q.filter(x=>x.status==='error').length;
  $('batchPanel').hidden=q.length===0;$('batchCount').textContent=`${q.length} pages · ${done} colored`;
  $('batchProgressFill').style.width=(q.length?Math.round((done+failed)/q.length*100):0)+'%';
  $('batchProgressLabel').textContent=state.generating?`Processing ${Math.min(done+failed+1,q.length)} of ${q.length}`:`${done} colored · ${failed} failed · ${q.length-done-failed} waiting`;
  $('generateLabel').textContent=state.generating?'Colorizing pages…':q.length?`Colorize ${q.filter(x=>x.status==='waiting'||x.status==='error').length} pages`:'Colorize my manga';
  $('stopBatch').hidden=!state.generating;
  $('clearQueue').disabled=state.generating;
  const list=$('batchList');list.replaceChildren();
  q.forEach((item,index)=>{
    const row=document.createElement('button');row.type='button';row.className='batch-row'+(index===state.selectedIndex?' active':'');row.title=item.error||item.filename;
    const num=document.createElement('span');num.className='batch-num';num.textContent=(index+1)+'.';
    const name=document.createElement('span');name.className='batch-name';name.textContent=item.filename;
    const status=document.createElement('span');status.className='batch-state'+(item.status==='saved'?' done':'')+((item.status==='error'||item.status==='save-error')?' error':'');status.textContent=stageStatus(item);
    row.append(num,name,status);row.addEventListener('click',()=>selectItem(index));list.append(row);
  });
}
async function selectItem(index){
  if(state.generating)return;
  if(index<0||index>=state.queue.length)return;
  state.selectedIndex=index;const item=state.queue[index];
  try{
    const encoded=item.sourceData?{data:item.sourceData,...item.dimensions}:await encodeFile(item.file,1800);
    if(!encoded.data||encoded.data.length>19_000_000)throw Error('Image too complex.');
    state.sourceData=encoded.data;state.source=encoded.data;state.result=item.resultData;state.processedResult=null;
    state.filename=item.filename;state.dimensions={w:encoded.w,h:encoded.h};state.sample=false;
    $('inkStrength').value=0;$('inkValue').textContent='0%';setCompare(52);updatePreview();renderQueue();
  }catch(err){toast(err.message||'Cannot load image.',true);}
}
function clearQueue(){if(state.generating)return;state.queue=[];state.selectedIndex=-1;state.history=[];state.batchFinished=0;state.batchTotal=0;loadSample();renderQueue();}
function setGenerating(value){state.generating=value;$('processingOverlay').hidden=!value;$('generateButton').disabled=value;renderQueue();}
async function handleReference(file){if(!file)return;const error=sizeError(file);if(error)return toast(error,true);try{const {data}=await encodeFile(file,1200);state.referenceData=data;$('referenceName').textContent=file.name;$('removeReference').hidden=false;toast('Color reference added.')}catch(e){toast(e.message,true)}}
function clearReference(){state.referenceData=null;$('referenceInput').value='';$('referenceName').textContent='Add a reference image';$('removeReference').hidden=true;}
function buildPayload(image){return {provider:state.provider,model:$('model').value,image,reference:state.provider==='huggingface'?null:state.referenceData,style:state.style,palette:$('palette').value,guidance:$('guidance').value,preserveText:$('preserveText').checked,ink:Math.min(100,75+Number($('inkStrength').value)/4),quality:$('quality').value};}
function isQuotaError(message){return /429|quota|RESOURCE_EXHAUSTED|billing|insufficient|credits|402|limit reached|exceeded/i.test(message);}
function saveBatchResult(item,result){
  if(!native())return;
  const filename=(item.filename.replace(/\.[^.]*$/,'')||'manga')+'-colorized.png';
  item.status='saving';galleryPending.set(item.id,item);renderQueue();
  InkBloomAndroid.savePngWithId(result,filename,item.id);
}
async function colorize(){
  if(state.generating)return;
  if(!state.connected)return toast('Save a valid '+state.provider+' API key before coloring.',true);
  if(!state.queue.length)return toast('Choose one or more manga images first.',true);
  let pending=state.queue.filter(item=>item.status==='waiting'||item.status==='error'||item.status==='save-error');
  if(!pending.length)return toast('All queued images are already processed. Add more images.',true);
  const cfg={provider:state.provider,model:$('model').value,style:state.style,palette:$('palette').value,guidance:$('guidance').value,preserveText:$('preserveText').checked,ink:Math.min(100,75+Number($('inkStrength').value)/4),quality:$('quality').value,reference:state.provider==='huggingface'?null:state.referenceData};
  state.stopRequested=false;setGenerating(true);let finished=0,failed=0,stopped=false;
  for(const item of pending){
    if(state.stopRequested){stopped=true;break;}
    const idx=state.queue.indexOf(item);item.status='working';item.error='';renderQueue();
    try {
      const input=await encodeFile(item.file,1800);if(input.data.length>19_000_000)throw Error('Image data too large.');
      const body=await promiseNative({...cfg,image:input.data});
      if(!body.image||!body.image.startsWith('data:image/'))throw Error('AI returned no image.');
      item.resultData=body.image;item.sourceData=input.data;item.dimensions={w:input.w,h:input.h};item.status='done';finished++;
      // Keeps a limited number of images in memory. All outputs are automatically exported to gallery.
      state.source=input.data;state.sourceData=input.data;state.result=body.image;state.processedResult=null;state.filename=item.filename;state.dimensions={...item.dimensions};state.sample=false;state.selectedIndex=idx;
      await applyInkOverlay();
      const output=state.processedResult||state.result;
      saveBatchResult(item,output);
      state.history.unshift({id:item.id,source:state.source,result:state.result,processedResult:state.processedResult,filename:item.filename,dimensions:{...state.dimensions}});
      while(state.history.length>6){const removed=state.history.pop();const old=state.queue.find(x=>x.id===removed.id);if(old){old.resultData=null;old.sourceData=null;}}
      state.activeHistory=item.id;setCompare(52);updatePreview();renderHistory();
    } catch(err) {
      const message=err.message||'Generation failed';item.error=message;item.status='error';failed++;console.error(message);
      toast(item.filename+': '+message,true);
      if(isQuotaError(message)){state.stopRequested=true;stopped=true;toast('Batch stopped: provider quota or billing issue. Completed pages remain saved.',true);}
    }
    renderQueue();
  }
  setGenerating(false);
  toast(stopped?`Stopped. ${finished} new pages colored, ${failed} failed.`:`Batch finished: ${finished} page(s) colored, ${failed} failed.`,failed>0);
}
async function applyInkOverlay(){
  const version=++state.inkVersion, opacity=Number($('inkStrength').value)/100;
  if(!state.result||opacity===0){state.processedResult=null;updatePreview();return;}
  try{
    const [original,edited]=await Promise.all([loadImage(state.source),loadImage(state.result)]);
    const w=edited.naturalWidth,h=edited.naturalHeight,c=document.createElement('canvas'),o=document.createElement('canvas');c.width=o.width=w;c.height=o.height=h;
    const ctx=c.getContext('2d',{willReadFrequently:true}),octx=o.getContext('2d',{willReadFrequently:true});
    ctx.drawImage(edited,0,0,w,h);octx.drawImage(original,0,0,w,h);
    const a=ctx.getImageData(0,0,w,h),b=octx.getImageData(0,0,w,h);
    for(let i=0;i<a.data.length;i+=4){const v=.2126*b.data[i]+.7152*b.data[i+1]+.0722*b.data[i+2];const weight=Math.pow(Math.max(0,Math.min(1,(190-v)/190)),2.4)*opacity*.93;for(let j=0;j<3;j++)a.data[i+j]=Math.round(a.data[i+j]*(1-weight));}
    ctx.putImageData(a,0,0);const data=c.toDataURL('image/png');if(version===state.inkVersion){state.processedResult=data;updatePreview();}
  }catch(err){console.error(err);toast('Ink overlay failed, keeping raw AI result.',true);}
}
function onInkChanged(){$('inkValue').textContent=$('inkStrength').value+'%';clearTimeout(inkDebounce);inkDebounce=setTimeout(()=>applyInkOverlay(),150);}
async function downloadPNG(){if(!state.result||state.sample)return toast('Colorize an image first.',true);const name=(state.filename.replace(/\.[^.]*$/,'')||'manga')+'-colorized.png';try{const img=await loadImage(state.processedResult||state.result);const c=document.createElement('canvas');c.width=img.naturalWidth;c.height=img.naturalHeight;c.getContext('2d').drawImage(img,0,0);InkBloomAndroid.savePng(c.toDataURL('image/png'),name);}catch(err){toast(err.message,true)}}
function renderHistory(){const box=$('history');box.replaceChildren();$('historyCount').textContent='('+state.history.length+')';if(!state.history.length){const e=document.createElement('div');e.className='empty-history';e.textContent='Generated results appear here';box.append(e);return;}
  state.history.forEach((item,i)=>{const btn=document.createElement('button');btn.type='button';btn.className='history-card'+(item.id===state.activeHistory?' active':'');const img=document.createElement('img');img.src=item.processedResult||item.result;img.alt='Colored manga preview';const num=document.createElement('span');num.textContent=String(i+1);btn.append(img,num);btn.addEventListener('click',()=>{state.source=item.source;state.sourceData=item.source;state.result=item.result;state.processedResult=item.processedResult;state.filename=item.filename;state.dimensions={...item.dimensions};state.sample=false;state.activeHistory=item.id;state.selectedIndex=state.queue.findIndex(q=>q.id===item.id);setCompare(52);updatePreview();renderHistory();renderQueue();});box.append(btn);});
}
function init(){
  selectProvider('huggingface');loadSample();renderQueue();renderHistory();
  $('provider').addEventListener('change',e=>selectProvider(e.target.value));
  $('saveApiKey').addEventListener('click',()=>{const key=$('apiKey').value.trim();if(!native()||!InkBloomAndroid.setApiKey(state.provider,key))return toast('Unable to save this API key. Check the format and length.',true);$('apiKey').value='';checkConnection();toast(state.provider+' API key securely saved.');});
  $('clearApiKey').addEventListener('click',()=>{InkBloomAndroid.clearApiKey(state.provider);checkConnection();toast('API key removed from this device.');});
  $('fileInput').addEventListener('change',e=>{const arr=Array.from(e.target.files||[]);handleFiles(arr);e.target.value='';});
  const zone=$('dropzone');zone.addEventListener('click',()=>$('fileInput').click());zone.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('fileInput').click()}});
  ['dragenter','dragover'].forEach(t=>zone.addEventListener(t,e=>{e.preventDefault();zone.classList.add('dragging')}));
  ['dragleave','dragend'].forEach(t=>zone.addEventListener(t,e=>{e.preventDefault();zone.classList.remove('dragging')}));
  zone.addEventListener('drop',e=>{e.preventDefault();zone.classList.remove('dragging');handleFiles(Array.from(e.dataTransfer?.files||[]))});
  $('clearQueue').addEventListener('click',clearQueue);
  $('stopBatch').addEventListener('click',()=>{state.stopRequested=true;$('stopBatch').textContent='Stopping after current page…';});
  $('demoButton').addEventListener('click',loadSample);$('resetButton').addEventListener('click',()=>{if(state.selectedIndex>=0)selectItem(state.selectedIndex);else loadSample();});
  document.querySelectorAll('[data-style]').forEach(btn=>btn.addEventListener('click',()=>{state.style=btn.dataset.style;document.querySelectorAll('[data-style]').forEach(b=>b.classList.toggle('selected',b===btn));}));
  $('referenceButton').addEventListener('click',()=>$('referenceInput').click());$('referenceInput').addEventListener('change',e=>handleReference(e.target.files[0]));$('removeReference').addEventListener('click',clearReference);
  $('generateButton').addEventListener('click',colorize);$('downloadButton').addEventListener('click',downloadPNG);
  $('inkStrength').addEventListener('input',onInkChanged);$('compareRange').addEventListener('input',e=>setCompare(e.target.value));
  let drag=false;const viewport=$('artViewport');const update=e=>{const r=viewport.getBoundingClientRect();setCompare((e.clientX-r.left)/r.width*100);};
  viewport.addEventListener('pointerdown',e=>{if(!state.result)return;drag=true;viewport.setPointerCapture(e.pointerId);update(e);});viewport.addEventListener('pointermove',e=>{if(drag)update(e);});viewport.addEventListener('pointerup',()=>drag=false);viewport.addEventListener('pointercancel',()=>drag=false);
  viewport.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();setCompare(state.compare+(e.key==='ArrowRight'?5:-5));}});
  $('fitButton').addEventListener('click',()=>setCompare(52));$('expandButton').addEventListener('click',()=>{$('lightboxImage').src=state.processedResult||state.result||state.source;$('lightbox').hidden=false;document.body.style.overflow='hidden';});
  const close=()=>{$('lightbox').hidden=true;document.body.style.overflow='';};$('closeLightbox').addEventListener('click',close);$('lightbox').addEventListener('click',e=>{if(e.target.id==='lightbox')close()});document.addEventListener('keydown',e=>{if(e.key==='Escape')close()});
}
init();
