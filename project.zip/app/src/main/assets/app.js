'use strict';
const $ = (id) => document.getElementById(id);
const state = {
  source: 'assets/demo-original.svg', result: 'assets/demo-colored.svg', processedResult: null,
  sourceData: null, referenceData: null, filename: 'demo_panel.png',
  sample: true, connected: false, protected: false, generating: false,
  style: 'classic', compare: 52, dimensions: {w:760,h:1100},
  history: [], activeHistory: null, inkVersion: 0
};
let toastTimer;
function toast(message, error=false) {
  const el=$('toast');el.textContent=message;el.classList.toggle('error',error);el.classList.add('show');
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove('show'),4700);
}
function setCompare(value) {
  const v=Math.max(0,Math.min(100,Number(value)));
  state.compare=v;
  $('compareDivider').style.left=`${v}%`;
  $('afterImage').style.clipPath=`inset(0 ${100-v}% 0 0)`;
  $('compareRange').value=v; $('compareValue').textContent=`${Math.round(v)}%`;
}
function updatePreview() {
  $('artViewport').style.aspectRatio=`${state.dimensions.w}/${state.dimensions.h}`;
  $('beforeImage').src=state.source;
  $('afterImage').src=state.processedResult||state.result||state.source;
  $('afterImage').style.display=state.result ? 'block' : 'none';
  $('compareDivider').style.display=state.result ? 'block' : 'none';
  $('compareRange').disabled=!state.result;
  $('downloadButton').disabled=!state.result;
  $('previewCaption').textContent=state.sample ? 'ILLUSTRATIVE DEMO' : (state.result ? 'AI COLOR RESULT' : 'ORIGINAL IMAGE');
  $('resolution').textContent=`${state.dimensions.w} × ${state.dimensions.h} PX`;
  $('fileName').textContent=state.filename;
  $('resultStatus').textContent=state.sample ? 'Illustrative sample — not AI generated' : state.result ? 'AI colorization ready to download' : 'Original uploaded — ready for AI colorization';
  $('resultStatusDot').classList.toggle('muted',!state.result);
}
function checkConnection(){
  state.connected=!!(window.InkBloomAndroid && InkBloomAndroid.hasApiKey());
  state.protected=false;
  $('passwordRow').hidden=true;
  const el=$('connection');el.classList.toggle('connected',state.connected);el.classList.toggle('offline',!state.connected);
  $('connectionText').textContent=state.connected?'AI service ready':'Add your API key';
}
let pendingColorization=null;
function colorizeOnAndroid(payload){
  return new Promise((resolve,reject)=>{
    if(!window.InkBloomAndroid)return reject(new Error('Android service unavailable.'));
    pendingColorization={resolve,reject};
    InkBloomAndroid.colorize(JSON.stringify(payload));
  });
}
window.inkbloomNativeResult = (result) => {
  if(!pendingColorization)return;
  const pending=pendingColorization;pendingColorization=null;
  if(result.error)pending.reject(new Error(result.error));
  else pending.resolve(result);
};

function sizeError(file) {
  if(!file) return 'No image selected.';
  if(!['image/png','image/jpeg','image/webp'].includes(file.type)) return 'Please use PNG, JPEG or WebP.';
  if(file.size>12*1024*1024) return 'Image exceeds 12 MB. Use a smaller file.';
  return '';
}
async function encodeFile(file,maxEdge=2048) {
  const objectUrl=URL.createObjectURL(file);
  try { return await encodeSrc(objectUrl,maxEdge); }
  finally { URL.revokeObjectURL(objectUrl); }
}
function loadImage(url) {
  return new Promise((resolve,reject)=>{
    const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(new Error('Unable to open image.'));img.src=url;
  });
}
async function encodeSrc(src,maxEdge=2048) {
  const img=await loadImage(src);
  const ratio=Math.min(1,maxEdge/Math.max(img.naturalWidth,img.naturalHeight));
  const w=Math.max(1,Math.round(img.naturalWidth*ratio)),h=Math.max(1,Math.round(img.naturalHeight*ratio));
  const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
  const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.fillStyle='#ffffff';ctx.fillRect(0,0,w,h);ctx.drawImage(img,0,0,w,h);
  return {data:canvas.toDataURL('image/png'),w,h};
}
async function handleFile(file) {
  const err=sizeError(file);if(err) return toast(err,true);
  try{
    const {data,w,h}=await encodeFile(file);
    if(data.length>16_000_000) return toast('This image is too complex. Try a smaller resolution.',true);
    state.source=data; state.sourceData=data;state.result=null;state.processedResult=null;state.sample=false;
    state.filename=file.name;state.dimensions={w,h};state.activeHistory=null;
    setCompare(52);updatePreview();renderHistory();
    toast('Image uploaded. Choose a style and colorize.');
  }catch(error){toast(error.message||'Unable to read image.',true)}
}
function loadSample(){
  state.source='assets/demo-original.svg';state.sourceData=null;state.result='assets/demo-colored.svg';
  state.processedResult=null;state.sample=true;state.filename='demo_panel.png';state.dimensions={w:760,h:1100};state.activeHistory=null;
  $('inkStrength').value='0';$('inkValue').textContent='0%';setCompare(52);updatePreview();renderHistory();
  toast('Sample loaded. This comparison is an illustration, not an AI result.');
}
async function handleReference(file){
  if(!file) return;
  const err=sizeError(file);if(err) return toast(err,true);
  try{
    const {data}=await encodeFile(file,1500);
    if(data.length>16_000_000) return toast('Reference image is too large.',true);
    state.referenceData=data; $('referenceName').textContent=file.name;$('removeReference').hidden=false;
    toast('Color reference added.');
  }catch(err){toast(err.message||'Unable to read reference.',true)}
}
function clearReference(){state.referenceData=null;$('referenceInput').value='';$('referenceName').textContent='Add a reference image';$('removeReference').hidden=true;}
function setGenerating(value) {
  state.generating=value;
  $('processingOverlay').hidden=!value;
  $('generateButton').disabled=value;
  $('generateLabel').textContent=value?'Colorizing your panel…':'Colorize my manga';
}
async function colorize(){
  if(state.generating) return;
  if(!state.connected){ toast('Add your OpenAI API key first.',true);return; }
  setGenerating(true);
  try{
    let input=state.sourceData;
    if(!input){const encoded=await encodeSrc(state.source);input=encoded.data;}
    const payload={image:input,reference:state.referenceData,style:state.style,palette:$('palette').value,
      guidance:$('guidance').value,preserveText:$('preserveText').checked,
      ink:Math.min(100,75+Number($('inkStrength').value)/4),quality:$('quality').value,model:$('model').value};
    const body=await colorizeOnAndroid(payload);
    if(!body.image || !body.image.startsWith('data:image/')) throw new Error('No image returned.');
    state.source=input;state.sourceData=input;state.result=body.image;state.processedResult=null;state.sample=false;state.activeHistory=null;
    const im=await loadImage(body.image);state.dimensions={w:im.naturalWidth,h:im.naturalHeight};
    await applyInkOverlay();
    const item={id:Date.now()+'-'+Math.random().toString(16).slice(2),source:state.source,result:state.result,
      processedResult:state.processedResult,filename:state.filename,dimensions:{...state.dimensions}};
    state.history.unshift(item);state.history=state.history.slice(0,6);state.activeHistory=item.id;
    setCompare(52);updatePreview();renderHistory();
    toast('Colorization finished! Drag the comparison handle to see the result.');
  }catch(err){console.error(err);toast(err.message||'Could not generate color.',true)}
  finally{setGenerating(false)}
}
async function applyInkOverlay(){
  const version=++state.inkVersion;
  const opacity=Number($('inkStrength').value)/100;
  if(!state.result||opacity===0){state.processedResult=null;updatePreview();return;}
  try{
    const [original,edited]=await Promise.all([loadImage(state.source),loadImage(state.result)]);
    const w=edited.naturalWidth,h=edited.naturalHeight;
    const c=document.createElement('canvas'),o=document.createElement('canvas');
    c.width=o.width=w;c.height=o.height=h;
    const ctx=c.getContext('2d',{willReadFrequently:true}),octx=o.getContext('2d',{willReadFrequently:true});
    ctx.drawImage(edited,0,0,w,h);octx.drawImage(original,0,0,w,h);
    const output=ctx.getImageData(0,0,w,h),ink=octx.getImageData(0,0,w,h);
    const dst=output.data,src=ink.data;
    for(let i=0;i<dst.length;i+=4){
      const luminance=(.2126*src[i]+.7152*src[i+1]+.0722*src[i+2]);
      const dark=Math.max(0,Math.min(1,(190-luminance)/190));
      const weight=Math.pow(dark,2.4)*opacity*.93;
      dst[i]=Math.round(dst[i]*(1-weight));dst[i+1]=Math.round(dst[i+1]*(1-weight));dst[i+2]=Math.round(dst[i+2]*(1-weight));
    }
    ctx.putImageData(output,0,0);
    const data=c.toDataURL('image/png');
    if(version===state.inkVersion){state.processedResult=data;updatePreview();}
  }catch(err){console.error('Overlay failed:',err);toast('Original ink overlay was skipped.',true);}
}
let inkDebounce;
function onInkChanged(){
  $('inkValue').textContent=`${$('inkStrength').value}%`;
  clearTimeout(inkDebounce);
  inkDebounce=setTimeout(()=>{applyInkOverlay().then(()=>{if(state.activeHistory){const item=state.history.find(x=>x.id===state.activeHistory);if(item)item.processedResult=state.processedResult;}})},160);
}
async function downloadPNG(){
  if(!state.result)return toast('Generate an image first.',true);
  try{
    const img=await loadImage(state.processedResult||state.result);
    const canvas=document.createElement('canvas');canvas.width=img.naturalWidth;canvas.height=img.naturalHeight;
    canvas.getContext('2d').drawImage(img,0,0);
    const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));
    if(!blob) throw new Error('Unable to export PNG.');
    const filename=(state.filename.replace(/\.[^.]*$/,'')||'manga')+'-colorized.png';
    const reader=new FileReader();
    reader.onload=()=>{InkBloomAndroid.savePng(reader.result,filename);toast('Saving PNG to Pictures/InkBloom…');};
    reader.onerror=()=>toast('Unable to save PNG.',true);
    reader.readAsDataURL(blob);
  }catch(err){toast(err.message||'Download failed.',true)}
}
function renderHistory(){
  $('historyCount').textContent=`(${state.history.length})`;
  const box=$('history');box.replaceChildren();
  if(!state.history.length){const e=document.createElement('div');e.className='empty-history';e.innerHTML='<span class="empty-icon">✧</span> Your generated results will appear here';box.appendChild(e);return;}
  state.history.forEach((item,i)=>{
    const btn=document.createElement('button');btn.type='button';btn.className='history-card'+(item.id===state.activeHistory?' active':'');btn.title=`Show color study ${state.history.length-i}`;
    const img=document.createElement('img');img.src=item.processedResult||item.result;img.alt='Past generated colorization';
    const span=document.createElement('span');span.textContent=`${state.history.length-i}`;
    btn.append(img,span);btn.addEventListener('click',()=>{
      state.source=item.source;state.sourceData=item.source;state.result=item.result;state.processedResult=item.processedResult;
      state.filename=item.filename;state.dimensions={...item.dimensions};state.sample=false;state.activeHistory=item.id;
      setCompare(52);updatePreview();renderHistory();
    });box.appendChild(btn);
  });
}
function init(){
  checkConnection();updatePreview();renderHistory();setCompare(52);
  $('saveApiKey').addEventListener('click',()=>{
    const key=$('apiKey').value.trim();
    if(!key.startsWith('sk-'))return toast('Paste a valid OpenAI API key beginning with sk-.',true);
    InkBloomAndroid.setApiKey(key);$('apiKey').value='';checkConnection();toast('API key saved securely on this device.');
  });
  $('fileInput').addEventListener('change',e=>{if(e.target.files[0])handleFile(e.target.files[0]);e.target.value='';});
  const zone=$('dropzone');zone.addEventListener('click',()=>$('fileInput').click());
  zone.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('fileInput').click();}});
  ['dragenter','dragover'].forEach(t=>zone.addEventListener(t,e=>{e.preventDefault();zone.classList.add('dragging');}));
  ['dragleave','dragend'].forEach(t=>zone.addEventListener(t,e=>{e.preventDefault();zone.classList.remove('dragging');}));
  zone.addEventListener('drop',e=>{e.preventDefault();zone.classList.remove('dragging');if(e.dataTransfer?.files?.[0])handleFile(e.dataTransfer.files[0]);});
  $('demoButton').addEventListener('click',loadSample);$('resetButton').addEventListener('click',loadSample);
  document.querySelectorAll('[data-style]').forEach(btn=>btn.addEventListener('click',()=>{
    state.style=btn.dataset.style;document.querySelectorAll('[data-style]').forEach(b=>b.classList.toggle('selected',b===btn));
  }));
  $('referenceButton').addEventListener('click',()=>$('referenceInput').click());
  $('referenceInput').addEventListener('change',e=>handleReference(e.target.files[0]));
  $('removeReference').addEventListener('click',clearReference);
  $('generateButton').addEventListener('click',colorize);$('downloadButton').addEventListener('click',downloadPNG);
  $('inkStrength').addEventListener('input',onInkChanged);
  $('compareRange').addEventListener('input',e=>setCompare(e.target.value));
  let dragging=false;
  const viewport=$('artViewport');
  const updateFromPointer=e=>{const r=viewport.getBoundingClientRect();setCompare((e.clientX-r.left)/r.width*100)};
  viewport.addEventListener('pointerdown',e=>{if(!state.result)return;dragging=true;viewport.setPointerCapture(e.pointerId);updateFromPointer(e);});
  viewport.addEventListener('pointermove',e=>{if(dragging)updateFromPointer(e);});
  viewport.addEventListener('pointerup',()=>dragging=false);viewport.addEventListener('pointercancel',()=>dragging=false);
  viewport.addEventListener('keydown',e=>{if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();setCompare(state.compare+(e.key==='ArrowRight'?5:-5));}});
  $('fitButton').addEventListener('click',()=>setCompare(52));
  $('expandButton').addEventListener('click',()=>{$('lightboxImage').src=state.processedResult||state.result||state.source;$('lightbox').hidden=false;document.body.style.overflow='hidden';});
  const close=()=>{$('lightbox').hidden=true;document.body.style.overflow='';};
  $('closeLightbox').addEventListener('click',close);$('lightbox').addEventListener('click',e=>{if(e.target.id==='lightbox')close();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')close();});
}
init();
