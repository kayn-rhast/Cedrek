# INKBLOOM Manga AI Colorizer v2.0 (Android)

Native Android WebView studio featuring Google Gemini, Hugging Face Qwen Image Edit, and OpenAI image editing.

## Key features

- Select **up to 100 manga pages in one gallery selection**, or add additional pages to the queue.
- Process queued pages sequentially, with per-page progress, stop-after-current, failed-page retries, and quota detection.
- **Automatically save each completed panel** as a PNG in `Pictures/InkBloom` through Android MediaStore.
- Maintain before/after comparison, color styles, palette direction, character notes, speech bubble preservation, and recent image history.
- Securely store one API key for each provider using Android Keystore AES-GCM. Keys are never embedded in the APK or sent to a third-party intermediary beyond the selected provider.

## What is actually free?

- **Hugging Face Qwen Image Edit:** Some free accounts have a tiny monthly inference credit allocation. As of Nov 2026, Hugging Face lists **$0.10/month subject to change**, which can be exhausted very quickly. A free Hugging Face token with Inference Providers permission is required. The model runs via the Hugging Face Fal routing provider; availability varies.
- **Gemini:** Google's Gemini *image generation* API models, including Flash Lite Image, show **no API free tier**. A Gemini API key tied to a billing-enabled project is required. The model selector defaults to the economical Flash Lite image model.
- **OpenAI:** Image editing uses billable OpenAI API credits.
- **No anonymous hosted AI quota** or unlimited free AI is provided by this APK. It is a bring-your-own-key client. This is intentional to keep credentials user-controlled and avoid claiming free processing that does not exist.

## Build

JDK 17, Gradle 8.9 and Android SDK 35:

```bash
gradle --no-daemon assembleDebug
```

Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Notes

- Install upgrade: GitHub Actions debug APKs may be signed with a different debug certificate. If Android reports a signature conflict, uninstall the old InkBloom APK, then install v2. Previous app-specific API keys will be lost when uninstalling and must be reentered.
- Internet is required for AI operations. Test requests against the provider with your own API key.
- Image editing can alter ink geometry, text, or panel borders despite preservation instructions. Inspect results before final use.
- Bulk process auto-saves outputs but remains subject to provider quotas, outages, rate limits, and billing.
